"""
Read from sql, nosql dbs by using this module and return dataframe as well as additional information

try with: postgres, mysql server, cassandra

"""