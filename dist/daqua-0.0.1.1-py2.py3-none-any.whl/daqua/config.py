"""
Created By: Satya Pati
Created on: 17-06-2021 00:36
"""


class Config:
    def __init__(self, path):
        self.file_path = path
        self.data_type = 'excel'